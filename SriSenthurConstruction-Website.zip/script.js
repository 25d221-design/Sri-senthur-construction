// Sri Senthur Construction website interactions
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

if (menuToggle && mainNav) {
  menuToggle.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
  });

  mainNav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      mainNav.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.setAttribute("aria-label", "Open navigation menu");
    });
  });
}

// Keep the copyright year current automatically.
const yearElement = document.getElementById("currentYear");
if (yearElement) {
  yearElement.textContent = new Date().getFullYear();
}

// Prepare a WhatsApp enquiry from the form. The visitor reviews and sends it.
const contactForm = document.getElementById("contactForm");
const formStatus = document.getElementById("formStatus");
if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const formData = new FormData(contactForm);
    const name = String(formData.get("name") || "").trim();
    const phone = String(formData.get("phone") || "").trim();
    const projectType = String(formData.get("projectType") || "").trim();
    const location = String(formData.get("location") || "").trim();
    const message = String(formData.get("message") || "").trim();

    if (!name || !phone || !projectType || !location) {
      if (formStatus) formStatus.textContent = "Please complete all required fields.";
      return;
    }

    const enquiry = [
      "Hello Sri Senthur Construction, I would like to enquire about a project.",
      "",
      `Name: ${name}`,
      `Phone: ${phone}`,
      `Project type: ${projectType}`,
      `Project location: ${location}`,
      `Details: ${message || "Not provided"}`
    ].join("\n");

    // Founder contact number, formatted for WhatsApp as country code + number.
    const whatsappNumber = "919786584384";
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(enquiry)}`;

    if (formStatus) formStatus.textContent = "Opening WhatsApp with your enquiry. Review it there and press Send.";
    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
  });
}
